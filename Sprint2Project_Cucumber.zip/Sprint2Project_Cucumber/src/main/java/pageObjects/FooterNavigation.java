package pageObjects;

import java.util.List;
//
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

//http://retailm1.upskills.in/

public class FooterNavigation {
	
public WebDriver driver;	
	
	public FooterNavigation(WebDriver driver) throws InterruptedException {
		// TODO Auto-generated constructor stub
		
		this.driver=driver;
		
//		driver.navigate().to("http://retailm1.upskills.in/about_us");
//        
//        Thread.sleep(2000);
//        
//         //driver.navigate().refresh();
//        
//        driver.navigate().to("http://retailm1.upskills.in/delivery");
//        
//        Thread.sleep(2000);
//        
//         driver.navigate().back();
//         
//         driver.navigate().to("http://retailm1.upskills.in/");
//        
//        Thread.sleep(2000);
//        
//         driver.navigate().forward();
//         
//         driver.navigate().to("http://retailm1.upskills.in/privacy");
//         
//         Thread.sleep(2000);
//         
//         driver.navigate().forward();
//         
//         driver.navigate().to("http://retailm1.upskills.in/terms");
//         
//         Thread.sleep(2000);
//         
//         driver.navigate().forward();
//         
//         driver.navigate().to("http://retailm1.upskills.in/information/contact");
//         
//         Thread.sleep(2000);
//         
//         driver.navigate().forward();
//         
//         driver.navigate().to("http://retailm1.upskills.in/information/sitemap");
//         
//         Thread.sleep(2000);
//         
//         driver.navigate().forward();
//         
//         driver.navigate().to("http://retailm1.upskills.in/");
//         
//         Thread.sleep(2000);
//       
//         driver.quit();
	
	}
	
}
